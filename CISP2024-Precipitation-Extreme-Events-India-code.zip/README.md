# Assessing Spatio-Temporal Precipitation Variability and Extreme Events in India

This repository contains code and data for the analysis of extreme precipitation in India using IMD station data from the year 1901 to 2022.

## Data Source

The IMD station data is downloaded from the official website of IMD [IMD Pune - Griddata](https://www.imdpune.gov.in/cmpg/Griddata/Rainfall_25_NetCDF.html). The country is divided into four regions based on the classification provided by IMD [IMD Rainfall Over Homogeneous Region](https://mausam.imd.gov.in/imd_latest/contents/rainfall_over_homogeneous.php).

## Analysis Steps

### 1. Identifying Extreme Rainfall

We define extreme rainfall as values higher than the 99th percentile of historical rainfall values. Any rainfall above this threshold is considered extreme, focusing on the most intense rainy days.

### 2. Analyzing Trends with Mann-Kendall Test

In our study, we used the Mann-Kendall test to analyze trends in extreme rainfall events. This non-parametric method detects monotonic trends in time series data without assuming any specific data distribution, making it ideal for environmental datasets where distributions may deviate from normality.

The test compares the ranks of data points within the time series, determining if there's a consistent upward or downward trend. A positive result indicates a significant trend toward increasing extreme rainfall events, while a negative result suggests a trend toward decreasing events. 
#### Justification for Using the Mann-Kendall Test

1. Non-parametric Nature: Robustness in the presence of non-normality or outliers.
2. Sensitivity to Trends: Detects gradual changes in extreme rainfall.
3. Applicability to Time Series Data: Well-suited for sequential observations over time.

### 3. Visualizing Positive Trends in a Map

In the temporal analysis, daily rainfall data is examined to identify patterns in extreme precipitation events. A threshold is calculated based on the 99th percentile of historical rainfall values, and anything exceeding this threshold is considered an extreme event. The Mann-Kendall test confirms a positive trend, suggesting an increase in extreme precipitation events.

### 4. Active and Break Spells of Indian Monsoon

The analysis includes the calculation of active and break spells in the Indian monsoon, comparing IMD, IMERG, and CHRIPS data. The normalised rainfall anomaly (NPA) is calculated for each day. If NPA is greater than 1 for three consecutive days or more it is an active period. If NPA is less than -1 for three consecutive days or more it is a break period. We compute the daily rainfall anomaly (rainfall on that day - mean rainfall for that day over 20 years). Then sort of normalisation by dividing the standard deviation of the rainfall on that date over 20 years.  

## Code Dependencies

The analysis code uses the following dependencies:
- `xarray` for working with NetCDF files.
- `pandas` for data manipulation.
- `matplotlib.pyplot` for visualizations.
- `scipy.stats` for statistical tests.

## Instructions to Reproduce the Analysis

1. **Data Download:**
   - Download IMD station data from [IMD Pune - Griddata](https://www.imdpune.gov.in/cmpg/Griddata/Rainfall_25_NetCDF.html). Download CHRIPS data from ['https://data.chc.ucsb.edu/products/CHIRPS-2.0/global_daily/netcdf/p25/chirps-v2.0']. And IMERG data from ['https://disc.gsfc.nasa.gov/datasets/GPM_3IMERGHHL_06/summary'].

2. **Code Files:**
   - The analysis code is available in the Jupyter Notebook file: `Extreme_Precipitation_Analysis.ipynb`.

3. **Dependencies:**
   - Ensure you have the necessary Python libraries installed. You can install them using the following:
     ```bash
     pip install -r requirements.txt
     ```

4. **Run the Analysis:**
   - Open the Jupyter Notebook and run each cell sequentially to reproduce the analysis.

## Plots Showing Extremes in Regions

The analysis includes visualizations showing extremes in the four regions of India.

## License

This project is open source. Feel free to use and modify the code as needed.

For any questions or issues, please contact Stefy Thomas at stefythomas@cusat.ac.in.
